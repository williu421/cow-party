requirements: 
    pygame 
    socket


start up the server before anything else 
change ur IP address    
fonts: 
    Broken Home
    28 Days Later 
    Gravedigger
        http://www.fontspace.com/chequered-ink/gravedigger
